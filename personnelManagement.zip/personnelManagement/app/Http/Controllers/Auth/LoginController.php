<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    /**
     * Show the login form.
     */
    public function showLoginForm()
    {
        return view('auth.login'); // or 'login' if your blade file is directly in resources/views
    }

    /**
     * Handle login request.
     */
    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required'],
        ]);

        if (Auth::attempt($credentials, $request->remember)) {
            $request->session()->regenerate();

            $user = Auth::user();

            // Role-based redirection
            if ($user->role === 'hrAdmin') {
                return redirect()->route('hrAdmin.dashboard');
            } elseif ($user->role === 'applicant') {
                return redirect()->route('applicant.dashboard'); // ✅ fixed here
            } elseif ($user->role === 'employee') {
                return redirect()->route('employee.dashboard');
            
             } elseif ($user->role === 'hrStaff') {
                return redirect()->route('hrStaff.dashboard');
            }


            // Fallback redirection
            return redirect()->intended('/home');
        }

        return back()->withErrors([
            'email' => 'The provided credentials do not match our records.',
        ])->onlyInput('email');
    }

    /**
     * Handle logout request.
     */
    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/login');
    }
}
