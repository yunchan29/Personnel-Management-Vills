@extends('layouts.hrAdmin')
@section('content')

@endsection 