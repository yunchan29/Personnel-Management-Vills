<a <?php echo e($attributes->merge(['class' => 'block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100'])); ?>>
    <?php echo e($slot); ?>

</a>
<?php /**PATH C:\Users\user\Documents\GitHub\Personnel-Management-Vills\personnelManagement\resources\views/components/dropdown-link.blade.php ENDPATH**/ ?>