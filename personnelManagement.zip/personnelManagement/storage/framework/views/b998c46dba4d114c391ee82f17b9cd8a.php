<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['job']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['job']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div 
    x-data="{ expanded: false }"
    class="bg-white border rounded-lg shadow-sm p-6 flex flex-col justify-between"
>
    
    <div class="flex justify-between items-start mb-4">
        <div>
            <h4 class="text-lg font-semibold text-[#BD6F22]"><?php echo e($job->job_title); ?></h4>
            <p class="text-sm text-gray-700"><?php echo e($job->company_name); ?></p>
        </div>
        <div class="text-right text-xs text-gray-500 leading-tight">
            <p>Last Posted: <?php echo e($job->created_at->diffForHumans()); ?></p>
            <p>Apply until: <?php echo e(\Carbon\Carbon::parse($job->apply_until)->format('F d, Y')); ?></p>
        </div>
    </div>

    
    <div class="flex items-start text-sm text-gray-600 mb-3">
        <img src="<?php echo e(asset('images/briefcaseblack.png')); ?>" alt="Qualifications" class="w-5 h-5 mr-2 mt-1">
        <div>
            <strong>Qualifications:</strong>
            <ul class="list-disc ml-6">
                <?php $__currentLoopData = $job->qualifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li x-show="expanded || <?php echo e($index); ?> < 3"><?php echo e($line); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>

    
    <?php if(!empty($job->additional_info)): ?>
        <div class="flex items-start text-sm text-gray-600 mb-3" x-show="expanded">
            <img src="<?php echo e(asset('images/info.png')); ?>" alt="Info" class="w-5 h-5 mr-2 mt-1">
            <div>
                <strong>Additional Info:</strong>
                <ul class="list-disc ml-6">
                    <?php $__currentLoopData = $job->additional_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($info); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    <?php endif; ?>

    
    <div class="flex items-center text-sm text-gray-600 mb-4">
        <img src="<?php echo e(asset('images/location.png')); ?>" alt="Location" class="w-5 h-5 mr-2">
        <span><?php echo e($job->location); ?></span>
    </div>

    
    <?php if(count($job->qualifications) > 3 || !empty($job->additional_info)): ?>
        <div class="flex justify-center w-full">
            <button 
                @click="expanded = !expanded" 
                class="text-[#BD6F22] text-xs hover:underline mb-3"
            >
                <span x-text="expanded ? 'See Less' : 'See More'"></span>
            </button>
        </div>
    <?php endif; ?>

    
    <div class="flex justify-end items-center text-sm">
      <a 
    href="<?php echo e(route('hrAdmin.applicants', $job->id)); ?>" 
    class="text-[#BD6F22] hover:underline flex items-center gap-1"
>
    View Applicants
    <span class="bg-red-600 text-white text-xs font-bold rounded-full px-2 py-0.5">
        <?php echo e($job->applications_count); ?>

    </span>
</a>


    </div>
</div>
<?php /**PATH C:\Users\user\Documents\GitHub\Personnel-Management-Vills\personnelManagement\resources\views/components/hradmin/applicationJobListing.blade.php ENDPATH**/ ?>