<?php $__env->startSection('content'); ?>
<section 
    class="p-6 max-w-6xl mx-auto"
    x-data
    x-init="$store.applications.tab = '<?php echo e($selectedTab ?? 'postings'); ?>'"
>
    <h1 class="mb-6 text-2xl font-bold text-[#BD6F22]">Applications</h1>
    <hr class="border-t border-gray-300 mb-6">

    
    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.store('applications', {
                tab: 'postings'
            });
        });
    </script>

    
    <?php $hasJob = isset($selectedJob); ?>
    <div class="flex space-x-8 text-sm font-medium text-gray-600 border-b border-gray-300 mb-6">
        <!-- Job Postings -->
        <button
            @click="$store.applications.tab = 'postings'"
            :class="$store.applications.tab === 'postings' 
                ? 'text-[#BD9168] border-b-2 border-[#BD9168] pb-2' 
                : 'hover:text-[#BD9168]'"
            class="pb-2 focus:outline-none"
        >
            Job Postings
        </button>

        <!-- Applicants -->
        <button
            x-on:click="$store.applications.tab = 'applicants'"
            x-bind:disabled="<?php echo e($hasJob ? 'false' : 'true'); ?>"
            :class="{
                'text-[#BD9168] border-b-2 border-[#BD9168] pb-2': $store.applications.tab === 'applicants',
                'text-gray-400 cursor-not-allowed': <?php echo e($hasJob ? 'false' : 'true'); ?>,
                'hover:text-[#BD9168]': <?php echo e($hasJob ? 'true' : 'false'); ?>

            }"
            class="pb-2 focus:outline-none"
        >
            Applicants
        </button>

        <!-- Interview Schedule -->
        <button
            x-on:click="$store.applications.tab = 'interview'"
            x-bind:disabled="<?php echo e($hasJob ? 'false' : 'true'); ?>"
            :class="{
                'text-[#BD9168] border-b-2 border-[#BD9168] pb-2': $store.applications.tab === 'interview',
                'text-gray-400 cursor-not-allowed': <?php echo e($hasJob ? 'false' : 'true'); ?>,
                'hover:text-[#BD9168]': <?php echo e($hasJob ? 'true' : 'false'); ?>

            }"
            class="pb-2 focus:outline-none"
        >
            Interview Schedule
        </button>

        <!-- Training Schedule -->
        <button
            x-on:click="$store.applications.tab = 'training'"
            x-bind:disabled="<?php echo e($hasJob ? 'false' : 'true'); ?>"
            :class="{
                'text-[#BD9168] border-b-2 border-[#BD9168] pb-2': $store.applications.tab === 'training',
                'text-gray-400 cursor-not-allowed': <?php echo e($hasJob ? 'false' : 'true'); ?>,
                'hover:text-[#BD9168]': <?php echo e($hasJob ? 'true' : 'false'); ?>

            }"
            class="pb-2 focus:outline-none"
        >
            Training Schedule
        </button>
    </div>

    
    <div 
        x-data="{ search: '' }" 
        x-show="$store.applications.tab === 'postings'" 
        x-transition:enter="transition ease-out duration-300"
        x-transition:enter-start="opacity-0 translate-y-2"
        x-transition:enter-end="opacity-100 translate-y-0"
        class="space-y-6"
    >
        
<div class="flex items-center mb-6 gap-4">
    
    <div class="flex items-center flex-1">
        <label for="search" class="mr-4 font-medium text-sm block">Search Position</label>
        <input 
            type="text"
            id="search"
            name="search"
            x-model="search"
            class="flex-1 border border-gray-300 rounded-md p-2 text-sm"
            placeholder="Enter job title..."
        >
    </div>
    
    <div x-data="{ open: false }" class="relative">
        <button type="button" 
            @click="open = !open" 
            class="border border-gray-300 rounded-md px-4 py-2 text-sm bg-white">
            Filters ▾
        </button>

        <div x-show="open" 
            @click.away="open = false"
            class="absolute mt-2 w-64 bg-white border border-gray-200 rounded-lg shadow-lg p-4 z-50">

            <form method="GET" action="<?php echo e(route('hrAdmin.application')); ?>" class="space-y-3">
                
                
                <div>
                    <p class="font-medium text-sm mb-1">Company</p>
                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="flex items-center space-x-2">
                            <input type="checkbox" name="company_name[]" value="<?php echo e($company); ?>"
                                <?php echo e(collect(request('company_name'))->contains($company) ? 'checked' : ''); ?>>
                            <span class="text-sm"><?php echo e($company); ?></span>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                
                <div>
                    <p class="font-medium text-sm mb-1">Sort</p>
                    <label class="flex items-center space-x-2">
                        <input type="radio" name="sort" value="latest" <?php echo e(request('sort') === 'latest' ? 'checked' : ''); ?>>
                        <span class="text-sm">Latest</span>
                    </label>
                    <label class="flex items-center space-x-2">
                        <input type="radio" name="sort" value="oldest" <?php echo e(request('sort') === 'oldest' ? 'checked' : ''); ?>>
                        <span class="text-sm">Oldest</span>
                    </label>
                    <label class="flex items-center space-x-2">
                        <input type="radio" name="sort" value="position_asc" <?php echo e(request('sort') === 'position_asc' ? 'checked' : ''); ?>>
                        <span class="text-sm">Position (A–Z)</span>
                    </label>
                    <label class="flex items-center space-x-2">
                        <input type="radio" name="sort" value="position_desc" <?php echo e(request('sort') === 'position_desc' ? 'checked' : ''); ?>>
                        <span class="text-sm">Position (Z–A)</span>
                    </label>
                </div>

                <button type="submit" class="mt-2 bg-blue-500 text-white px-4 py-1 rounded-md text-sm">
                    Apply
                </button>
            </form>
        </div>
    </div>
</div>


        
        <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $jobTitle = Js::from(strtolower($job->job_title));
                $companyName = Js::from(strtolower($job->company_name));
                $location = Js::from(strtolower($job->location));
                $qualifications = Js::from(strtolower(implode(' ', $job->qualifications)));
                $additionalInfo = Js::from(strtolower(implode(' ', $job->additional_info ?? [])));
            ?>

            <div 
                x-show="search === '' 
                    || <?php echo e($jobTitle); ?>.includes(search.toLowerCase()) 
                    || <?php echo e($companyName); ?>.includes(search.toLowerCase()) 
                    || <?php echo e($location); ?>.includes(search.toLowerCase()) 
                    || <?php echo e($qualifications); ?>.includes(search.toLowerCase()) 
                    || <?php echo e($additionalInfo); ?>.includes(search.toLowerCase())"
                x-transition
            >
                <?php if (isset($component)) { $__componentOriginal4871ecc32e4f20ec863b140435da55f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4871ecc32e4f20ec863b140435da55f2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.hradmin.applicationJobListing','data' => ['job' => $job]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('hradmin.applicationJobListing'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['job' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4871ecc32e4f20ec863b140435da55f2)): ?>
<?php $attributes = $__attributesOriginal4871ecc32e4f20ec863b140435da55f2; ?>
<?php unset($__attributesOriginal4871ecc32e4f20ec863b140435da55f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4871ecc32e4f20ec863b140435da55f2)): ?>
<?php $component = $__componentOriginal4871ecc32e4f20ec863b140435da55f2; ?>
<?php unset($__componentOriginal4871ecc32e4f20ec863b140435da55f2); ?>
<?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-center text-gray-500">No job applications available.</p>
        <?php endif; ?>
    </div>

    
    <div 
        x-show="$store.applications.tab === 'applicants'" 
        x-transition:enter="transition ease-out duration-300"
        x-transition:enter-start="opacity-0 translate-y-2"
        x-transition:enter-end="opacity-100 translate-y-0"
    >
        <?php if(isset($selectedJob) && isset($applications)): ?>
        <div 
            x-data="{ showNotice: true }"
            x-show="showNotice"
            x-transition
            x-cloak
            class="mb-4 bg-blue-100 border border-blue-300 text-blue-800 px-4 py-3 rounded-lg flex justify-between items-center"
            x-if="showNotice"
        >
            <span>
                You are viewing applicants for: 
                <strong class="text-[#1E3A8A]"><?php echo e($selectedJob->company_name); ?></strong> 
                <span class="text-gray-500">—</span> 
                <strong class="text-[#BD6F22]"><?php echo e($selectedJob->job_title); ?></strong>
            </span>

            <button 
                @click="showNotice = false" 
                class="text-sm text-blue-600 hover:underline"
            >
                Dismiss
            </button>
        </div>


            <?php echo $__env->make('hrAdmin.applicants', [
                'applications' => $applications,
                'selectedJob' => $selectedJob,
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php else: ?>
            <p class="text-gray-500 text-center">No applicants selected yet.</p>
        <?php endif; ?>
    </div>
    

    
    <div 
        x-show="$store.applications.tab === 'interview'" 
        x-transition:enter="transition ease-out duration-300"
        x-transition:enter-start="opacity-0 translate-y-2"
        x-transition:enter-end="opacity-100 translate-y-0"
        class="space-y-4"
    >
        <?php if(isset($approvedApplicants) && $approvedApplicants->count() > 0): ?>
            <?php echo $__env->make('hrAdmin.interviewSchedule',['approvedApplicants' => $approvedApplicants], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php else: ?>
            <p class="text-center text-gray-500">No applicants scheduled for interview.</p>
        <?php endif; ?>
    </div>

    
    <div 
        x-show="$store.applications.tab === 'training'" 
        x-transition:enter="transition ease-out duration-300"
        x-transition:enter-start="opacity-0 translate-y-2"
        x-transition:enter-end="opacity-100 translate-y-0"
        class="space-y-4"
    >
        <?php if(isset($interviewApplicants) && $interviewApplicants->isNotEmpty()): ?>
            <?php echo $__env->make('hrAdmin.trainingSchedule',['interviewApplicants' => $interviewApplicants], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php else: ?>
            <p class="text-center text-gray-500">No approved applicants for training yet.</p>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

<?php echo $__env->make('layouts.hrAdmin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Documents\GitHub\Personnel-Management-Vills\personnelManagement\resources\views/hrAdmin/application.blade.php ENDPATH**/ ?>