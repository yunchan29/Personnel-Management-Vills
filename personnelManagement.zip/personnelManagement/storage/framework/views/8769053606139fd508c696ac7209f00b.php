<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['currentRoute']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['currentRoute']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $items = [
        ['img' => 'home.png', 'label' => 'Home', 'route' => 'applicant.dashboard'],
        ['img' => 'user.png', 'label' => 'Profile', 'route' => 'applicant.profile'],
        ['img' => 'application.png', 'label' => 'My Application', 'route' => 'applicant.application'],
        ['img' => 'folder.png', 'label' => '201 Files', 'route' => 'applicant.files'],
        ['img' => 'settings.png', 'label' => 'Settings', 'route' => 'applicant.settings'],
    ];
?>

<div x-data="{ open: window.innerWidth >= 640 }"
     x-init="$watch('open', value => {});"
     @resize.window="open = window.innerWidth >= 640">

    <!-- Sidebar (desktop only) -->
    <aside x-show="window.innerWidth >= 640"
           :class="open ? 'w-40' : 'w-16'"
           class="hidden sm:flex sticky top-0 bg-white shadow-md h-screen transition-all duration-300 flex-col">

        <!-- Toggle -->
        <div class="flex justify-end p-2">
            <button @click="open = !open" class="text-[#8B4513] focus:outline-none">
                <svg :class="open ? 'rotate-180' : ''"
                     class="w-5 h-5 transition-transform duration-300"
                     fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7" />
                </svg>
            </button>
        </div>

        <!-- Vertical Menu -->
        <nav class="px-2 py-4 space-y-2">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="relative group">
                    <a href="<?php echo e(route($item['route'])); ?>"
                       class="flex flex-col items-center p-2 rounded-md border transition duration-150 ease-in-out
                              <?php echo e(request()->routeIs($item['route']) 
                                  ? 'border-b-4 border-[#8B4513] text-[#8B4513] bg-[#F9F6F3] font-semibold'
                                  : 'text-[#8B4513] hover:bg-gray-100 border-gray-200'); ?>">
                        <img src="/images/<?php echo e($item['img']); ?>"
                             class="w-8 h-8 mb-1"
                             alt="<?php echo e($item['label']); ?>">
                        <template x-if="open">
                            <span class="text-xs leading-tight text-center"><?php echo e($item['label']); ?></span>
                        </template>
                    </a>

                    <!-- Animated Tooltip -->
                    <div x-show="!open"
                         x-transition:enter="transition ease-out duration-200"
                         x-transition:enter-start="opacity-0 -translate-x-2 scale-95"
                         x-transition:enter-end="opacity-100 translate-x-0 scale-100"
                         x-transition:leave="transition ease-in duration-100"
                         x-transition:leave-start="opacity-100 translate-x-0 scale-100"
                         x-transition:leave-end="opacity-0 -translate-x-2 scale-95"
                         class="absolute left-full top-1/2 -translate-y-1/2 ml-2 px-2 py-1 bg-[#8B4513] text-white text-xs rounded shadow-lg whitespace-nowrap z-50 hidden group-hover:block">
                        <?php echo e($item['label']); ?>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>
    </aside>

    <!-- Bottom Nav (mobile only) -->
    <nav class="sm:hidden fixed bottom-0 left-0 right-0 bg-white border-t shadow-inner z-50 flex justify-around py-2">
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route($item['route'])); ?>"
               class="flex flex-col items-center text-[#8B4513] text-xs <?php echo e(request()->routeIs($item['route']) ? 'font-semibold' : ''); ?>">
                <img src="/images/<?php echo e($item['img']); ?>" class="w-6 h-6 mb-0.5" alt="<?php echo e($item['label']); ?>">
                <span><?php echo e($item['label']); ?></span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </nav>
</div>
<?php /**PATH C:\Users\user\Documents\GitHub\Personnel-Management-Vills\personnelManagement\resources\views/components/applicant/sidebar.blade.php ENDPATH**/ ?>