<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['currentRoute']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['currentRoute']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<aside x-data="{ open: true }" :class="open ? 'w-40' : 'w-16'" class="sticky top-0 bg-white shadow-md h-screen transition-all duration-300">

    <div class="flex justify-end p-2">
        <button @click="open = !open" class="text-[#8B4513] focus:outline-none">
            <svg :class="open ? 'rotate-180' : ''" class="w-5 h-5 transition-transform" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7" />
            </svg>
        </button>
    </div>
    <nav class="px-2 py-4 space-y-2">
        <?php
            $items = [
                ['img' => 'home.png', 'label' => 'Home', 'route' => 'hrAdmin.dashboard'],
                ['img' => 'search.png', 'label' => 'Job Posting', 'route' => 'hrAdmin.jobPosting'],
                ['img' => 'application.png', 'label' => 'Applications', 'route' => 'hrAdmin.application'],
                
                ['img' => 'leaveForm.png', 'label' => 'Leave Forms', 'route' => 'hrAdmin.leaveForm'],
                ['img' => 'employees.png', 'label' => 'Employees', 'route' => 'hrAdmin.employees'],
                ['img' => 'archive.png', 'label' => 'Archive', 'route' => 'hrAdmin.archive.index'],
                ['img' => 'settings.png', 'label' => 'Settings', 'route' => 'hrAdmin.settings'],
               
            ];
        ?>

        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route($item['route'])); ?>"
               class="flex flex-col items-center p-2 rounded border 
                      <?php echo e(request()->routeIs($item['route']) ? 'border-b-4 border-[#8B4513] text-[#8B4513]
' : 'text-[#8B4513] hover:bg-gray-100 border-gray-200'); ?>">
                <img src="/images/<?php echo e($item['img']); ?>" class="w-8 h-8 mb-1" alt="<?php echo e($item['label']); ?>">
                <template x-if="open">
                    <span class="text-xs"><?php echo e($item['label']); ?></span>
                </template>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </nav>
</aside>
<?php /**PATH C:\Users\user\Documents\GitHub\Personnel-Management-Vills\personnelManagement\resources\views/components/hrAdmin/sidebar.blade.php ENDPATH**/ ?>