<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['user']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['user']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<!-- Profile Modal -->
<div x-show="showProfile && activeProfileId === <?php echo e($user->id); ?>"
     x-transition
     class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
     x-cloak>
    <div class="bg-white rounded-lg overflow-y-auto max-h-[90vh] w-[95%] max-w-6xl shadow-xl relative p-6">
        <button @click="showProfile = false"
                class="absolute top-3 right-4 text-gray-500 hover:text-red-500 text-xl font-bold">
            &times;
        </button>

        <div x-data="{ tab: 'profile' }" class="flex flex-col md:flex-row gap-6">
            <!-- Sidebar -->
            <div class="flex justify-center md:justify-start flex-shrink-0 w-full md:w-auto">
                <div class="flex flex-col items-center text-center">
                    <img src="<?php echo e($user->profile_picture ? asset('storage/' . $user->profile_picture) : asset('images/default.png')); ?>"
                         alt="Profile Picture"
                         class="rounded-full w-36 h-36 object-cover border-2 border-gray-300 shadow-md mb-3">
                    <h1 class="text-lg font-semibold text-[#BD6F22]">
                        <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>

                    </h1>
                </div>
            </div>

            <!-- Main Content -->
            <div class="flex-1">
                <!-- Tabs -->
                <div class="flex space-x-6 border-b mb-4 text-sm font-medium">
                    <button @click="tab = 'profile'"
                            :class="tab === 'profile' ? 'border-b-2 border-[#BD6F22] text-[#BD6F22]' : ''"
                            class="pb-2">Profile</button>
                    <button @click="tab = 'work'"
                            :class="tab === 'work' ? 'border-b-2 border-[#BD6F22] text-[#BD6F22]' : ''"
                            class="pb-2">Work Experience</button>
                    <button @click="tab = 'files'"
                            :class="tab === 'files' ? 'border-b-2 border-[#BD6F22] text-[#BD6F22]' : ''"
                            class="pb-2">201 Files</button>
                </div>

                <!-- Tab Contents -->
                <div x-show="tab === 'profile'" x-cloak>
                    <?php echo $__env->make('components.hrAdmin.applicantProfile', ['user' => $user], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <div x-show="tab === 'work'" x-cloak>
                    <?php echo $__env->make('components.hrAdmin.applicantWorkExperience', [
                        'experiences' => $user->workExperiences,
                        'user' => $user
                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <div x-show="tab === 'files'" x-cloak>
                    <?php echo $__env->make('components.hrAdmin.applicant201', ['user' => $user], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\user\Documents\GitHub\Personnel-Management-Vills\personnelManagement\resources\views/components/hrAdmin/modals/profile.blade.php ENDPATH**/ ?>