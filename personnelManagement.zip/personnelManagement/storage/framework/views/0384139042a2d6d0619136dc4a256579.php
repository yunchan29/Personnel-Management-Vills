<!-- resources/views/errors/404.blade.php -->


<?php $__env->startSection('content'); ?>
    <div class="text-center mt-5">
        <h1 class="display-4">404</h1>
        <p class="lead">Page not found.</p>
        <a href="<?php echo e(url('/')); ?>" class="btn btn-primary">Go Home</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.applicantHome', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Documents\GitHub\Personnel-Management-Vills\personnelManagement\resources\views/errors/404.blade.php ENDPATH**/ ?>