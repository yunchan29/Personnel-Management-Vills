



<div class="border-t border-gray-300 pt-4">
    <!-- Government Documents -->
    <h3 class="text-lg font-semibold text-[#BD6F22] mb-3">Government Documents</h3>
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
        <?php
            $sss = $file201->sss_number ?? '-';
            $philhealth = $file201->philhealth_number ?? '-';
            $pagibig = $file201->pagibig_number ?? '-';
            $tin = $file201->tin_id_number ?? '-';
        ?>

        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">SSS number:</label>
            <input type="text" readonly value="<?php echo e($sss); ?>"
                   class="w-full bg-gray-100 cursor-not-allowed border border-gray-300 rounded-md px-3 py-2" />
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Philhealth number:</label>
            <input type="text" readonly value="<?php echo e($philhealth); ?>"
                   class="w-full bg-gray-100 cursor-not-allowed border border-gray-300 rounded-md px-3 py-2" />
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Pag-Ibig number:</label>
            <input type="text" readonly value="<?php echo e($pagibig); ?>"
                   class="w-full bg-gray-100 cursor-not-allowed border border-gray-300 rounded-md px-3 py-2" />
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Tin ID number:</label>
            <input type="text" readonly value="<?php echo e($tin); ?>"
                   class="w-full bg-gray-100 cursor-not-allowed border border-gray-300 rounded-md px-3 py-2" />
        </div>
    </div>

    <!-- Licenses / Certifications -->
    <h3 class="text-lg font-semibold text-[#BD6F22] mb-3">Licenses / Certifications</h3>

    <?php
        $licenses = $file201->licenses ?? [];
    ?>

    <?php $__empty_1 = true; $__currentLoopData = $licenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $license): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="border-t border-gray-200 py-4">
            <h4 class="text-md font-semibold text-gray-700 mb-2">
                License / Certification #<?php echo e($index + 1); ?>

            </h4>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">License / Certification</label>
                    <input type="text" readonly
                           value="<?php echo e($license['name'] ?? '-'); ?>"
                           class="w-full bg-gray-100 cursor-not-allowed border border-gray-300 rounded-md px-3 py-2" />
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">License Number</label>
                    <input type="text" readonly
                           value="<?php echo e($license['number'] ?? '-'); ?>"
                           class="w-full bg-gray-100 cursor-not-allowed border border-gray-300 rounded-md px-3 py-2" />
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Date Taken</label>
                    <input type="text" readonly
                           value="<?php echo e(!empty($license['date']) ? \Carbon\Carbon::parse($license['date'])->format('F d, Y') : '-'); ?>"
                           class="w-full bg-gray-100 cursor-not-allowed border border-gray-300 rounded-md px-3 py-2" />
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-sm text-gray-500 italic">No licenses/certifications recorded.</p>
    <?php endif; ?>

    <!-- License Summary -->
    <?php if(count($licenses)): ?>
        <div class="mt-6">
            <h4 class="text-md font-semibold text-[#BD6F22] mb-2">Summary of License / Certification Names</h4>
            <ul class="list-disc list-inside text-sm text-gray-800">
                <?php $__currentLoopData = $licenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $license): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!empty($license['name'])): ?>
                        <li><?php echo e($license['name']); ?></li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
</div>


<?php /**PATH C:\Users\user\Documents\GitHub\Personnel-Management-Vills\personnelManagement\resources\views/components/hrAdmin/applicant201.blade.php ENDPATH**/ ?>