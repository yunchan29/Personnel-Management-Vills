<div class="relative" x-data="{ open: false }">
    <div @click="open = ! open">
        <?php echo e($trigger); ?>

    </div>

    <div x-show="open"  x-cloak class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-xl z-20">
        <?php echo e($content); ?>

    </div>
</div>
<?php /**PATH C:\Users\user\Documents\GitHub\Personnel-Management-Vills\personnelManagement\resources\views/components/dropdown.blade.php ENDPATH**/ ?>