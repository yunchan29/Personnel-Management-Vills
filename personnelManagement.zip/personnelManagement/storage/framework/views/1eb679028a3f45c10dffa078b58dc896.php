<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e($title ?? 'HR Admin Dashboard'); ?> - VillsPMS</title>
     <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset('images/villslogo3.png')); ?>" type="image/png">
    <script src="https://cdn.tailwindcss.com"></script>
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Alata&display=swap" rel="stylesheet">
    <style>
@keyframes checkmark {
    0% {
        stroke-dashoffset: 22;
    }
    100% {
        stroke-dashoffset: 0;
    }
}
@keyframes progressBar {
    0% {
        width: 100%;
    }
    100% {
        width: 0%;
    }
}
.animate-checkmark path {
    stroke-dasharray: 22;
    stroke-dashoffset: 22;
    animation: checkmark 0.5s ease-out forwards;
}
.animate-progress-bar {
    animation: progressBar 3s linear forwards;
}
</style>

    <style>
    .font-alata { font-family: 'Alata', sans-serif; }
    [x-cloak] { display: none !important; }
    </style>
</head>
<body class="bg-gray-100 font-alata min-h-screen">

    <?php if (isset($component)) { $__componentOriginal8b017c9029e4b193b323013bc6367966 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b017c9029e4b193b323013bc6367966 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.hrAdmin.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('hrAdmin.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b017c9029e4b193b323013bc6367966)): ?>
<?php $attributes = $__attributesOriginal8b017c9029e4b193b323013bc6367966; ?>
<?php unset($__attributesOriginal8b017c9029e4b193b323013bc6367966); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b017c9029e4b193b323013bc6367966)): ?>
<?php $component = $__componentOriginal8b017c9029e4b193b323013bc6367966; ?>
<?php unset($__componentOriginal8b017c9029e4b193b323013bc6367966); ?>
<?php endif; ?>

    <div class="flex" x-data="{ open: true }">
    <?php if (isset($component)) { $__componentOriginal6aaa64cacef925401f36f33417e1eec7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6aaa64cacef925401f36f33417e1eec7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.hrAdmin.sidebar','data' => ['currentRoute' => Route::currentRouteName()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('hrAdmin.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['currentRoute' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(Route::currentRouteName())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6aaa64cacef925401f36f33417e1eec7)): ?>
<?php $attributes = $__attributesOriginal6aaa64cacef925401f36f33417e1eec7; ?>
<?php unset($__attributesOriginal6aaa64cacef925401f36f33417e1eec7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6aaa64cacef925401f36f33417e1eec7)): ?>
<?php $component = $__componentOriginal6aaa64cacef925401f36f33417e1eec7; ?>
<?php unset($__componentOriginal6aaa64cacef925401f36f33417e1eec7); ?>
<?php endif; ?>

        <main class="flex-1 p-6">
            <div class="bg-white rounded-lg shadow-lg p-6 h-full">
            
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>
    </div>
<script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</body>
</html>
<?php /**PATH C:\Users\user\Documents\GitHub\Personnel-Management-Vills\personnelManagement\resources\views/layouts/hrAdmin.blade.php ENDPATH**/ ?>