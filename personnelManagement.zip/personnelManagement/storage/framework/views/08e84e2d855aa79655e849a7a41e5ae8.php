<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title ?? 'Applicant Dashboard'); ?> - VillsPMS</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
     <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset('images/villslogo3.png')); ?>" type="image/png">
    <script src="https://cdn.tailwindcss.com"></script>
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Alata&display=swap" rel="stylesheet">
    <style>
        .font-alata { font-family: 'Alata', sans-serif; }
        [x-cloak] { display: none !important; }
    </style>
</head>
<body class="bg-gray-100 font-alata min-h-screen">

    <!-- Global Loading Screen -->
    <div id="loading-overlay" class="fixed inset-0 bg-white bg-opacity-75 flex items-center justify-center z-50 hidden">
        <div class="flex items-center space-x-4">
            <svg class="animate-spin h-8 w-8 text-[#BD9168]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                <path class="opacity-75" fill="currentColor"
                    d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
            </svg>
            <span class="text-[#BD9168] font-semibold text-lg">Loading...</span>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal78a430b58a4298d8f5b869203a78aa04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal78a430b58a4298d8f5b869203a78aa04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.applicant.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('applicant.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal78a430b58a4298d8f5b869203a78aa04)): ?>
<?php $attributes = $__attributesOriginal78a430b58a4298d8f5b869203a78aa04; ?>
<?php unset($__attributesOriginal78a430b58a4298d8f5b869203a78aa04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal78a430b58a4298d8f5b869203a78aa04)): ?>
<?php $component = $__componentOriginal78a430b58a4298d8f5b869203a78aa04; ?>
<?php unset($__componentOriginal78a430b58a4298d8f5b869203a78aa04); ?>
<?php endif; ?>

    <div class="flex" x-data="{ open: true }">
        <?php if (isset($component)) { $__componentOriginal61997ad740fb49ad1e684b7575a80c0a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal61997ad740fb49ad1e684b7575a80c0a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.applicant.sidebar','data' => ['currentRoute' => Route::currentRouteName()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('applicant.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['currentRoute' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(Route::currentRouteName())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal61997ad740fb49ad1e684b7575a80c0a)): ?>
<?php $attributes = $__attributesOriginal61997ad740fb49ad1e684b7575a80c0a; ?>
<?php unset($__attributesOriginal61997ad740fb49ad1e684b7575a80c0a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal61997ad740fb49ad1e684b7575a80c0a)): ?>
<?php $component = $__componentOriginal61997ad740fb49ad1e684b7575a80c0a; ?>
<?php unset($__componentOriginal61997ad740fb49ad1e684b7575a80c0a); ?>
<?php endif; ?>
        <main class="flex-1 p-6">
            <div class="bg-white rounded-lg shadow-lg p-6 h-full">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>
    </div>

    <script>
        const loadingOverlay = document.getElementById('loading-overlay');

        // Show loading screen on form submission
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', () => {
                loadingOverlay.classList.remove('hidden');
            });
        });

        // Show loading screen on page link click (except external, hash, JS, or new tab)
        document.querySelectorAll('a[href]').forEach(link => {
            const href = link.getAttribute('href');
            if (href && !href.startsWith('#') && !href.startsWith('javascript:') && !link.hasAttribute('target')) {
                link.addEventListener('click', () => {
                    setTimeout(() => {
                        loadingOverlay.classList.remove('hidden');
                    }, 50);
                });
            }
        });
    </script>

</body>
</html>
<?php /**PATH C:\Users\user\Documents\GitHub\Personnel-Management-Vills\personnelManagement\resources\views/layouts/applicantHome.blade.php ENDPATH**/ ?>